<a href="dashboard.php">Dashboard</a>&nbsp;
<a href="category.php">Category</a>&nbsp;
<a href="expense.php">Expense</a>&nbsp;
<a href="reports.php">Reports</a>&nbsp;
<a href="logout.php">Logout</a>