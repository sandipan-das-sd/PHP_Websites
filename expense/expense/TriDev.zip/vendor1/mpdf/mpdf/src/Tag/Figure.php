<?php

namespace Mpdf\Tag;

class Figure extends BlockTag
{


}
